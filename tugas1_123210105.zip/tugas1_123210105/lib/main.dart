import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('Pertemuan 2'),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Text(
                'Nama: Husnan Maulana Suprayitno',
                style: TextStyle(fontSize: 18),
              ),
              Text(
                'NIM: 123210105',
                style: TextStyle(fontSize: 18),
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Ini Tugas 2'),
              ),
              ElevatedButton(
                onPressed: () {},
                child: Text("Button 1"),
              ),
              OutlinedButton(
                onPressed: () {},
                child: Text("Button 2"),
              ),
              Image.asset('assets/Waduh1.jpeg'),
              Image.asset('assets/Waduh2.jpeg'),
              Image.asset('assets/Waduh3.webp')
            ],
          ),
        ),
      ),
    );
  }
}